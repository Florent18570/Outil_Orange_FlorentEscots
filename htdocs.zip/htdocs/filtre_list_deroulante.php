<script>
                        // Fonction permettant de retouné la valeur du champ choisi dans la liste déroulante et de l'afficher
                        function listmultipleresult() {
                            var spanresult = document.getElementById("result");
                            spanresult.value = "";
                            var tabresult = [];
                            var tourresult = 0;
                            var x = document.getElementById("selectmetier");

                            // Récupération de la valeur de retour de la liste de déroulant des métiers
                            for (var i = 0; i < x.options.length; i++) {
                                if (x.options[i].selected === true) {
                                    spanresult.value += x.options[i].value + " ";
                                    tabresult[tourresult] = x.options[i].value;
                                    document.getElementById("result").innerHTML = spanresult.value;
                                    document.getElementById("result").style.color = "green";
                                    tourresult++;
                                    document.getElementById("result_deroulant").value = spanresult.value;

                                }

                            }
                            for (var i = 0; i < tabresult.length; i++) {
                                //requete tab result de i 
                                // document.write(tabresult[i]);
                                document.getElementById("deroulant" + i).value = tabresult[i];

                            }
                            // Si rien n'est selectionner dans la liste déroulante alors un message en rouge s'affiche
                            if (document.getElementById("result").value == "") {
                                document.getElementById("result").innerHTML = "Vous pouvez selectionné plusieurs métier en restant appuyer sur ctrl en selectionnant un métier";
                                document.getElementById("result").style.color = "Red";
                            }


                        }
                    </script>
