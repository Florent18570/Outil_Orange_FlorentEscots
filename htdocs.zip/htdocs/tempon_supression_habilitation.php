<?php
session_start();


try {
    $bdd = new PDO('mysql:host=localhost;dbname=Orange;charset=utf8', 'root', '');
} catch (Exception $e) {
    die('Erreur : ' . $e->getMessage());
}

echo $_SESSION["Pole"];
if ($_SESSION["Pole"] == "RSI" ) {


//permet de faire un update de l'info supplémentaire selon id de l'app

$sql4 = "UPDATE `etat_habilitation` SET `Etat`='3' WHERE `Application` = '" . $_POST['Application'] . "' AND `CUID` = '" . $_SESSION['Identifiant'] . "' ";
echo $sql4;
$result4 = $bdd->query($sql4);

// header('Location: ' . $_SERVER['HTTP_REFERER']);

 }
else{

    $sql = "UPDATE `etat_habilitation` SET `Etat`='4' WHERE   `Application` = '" . $_POST['Application'] . "' and `CUID` = '" . $_SESSION['Identifiant'] . "' ";
    echo $sql;
    $result = $bdd->query($sql);


    // $result4 = $bdd->query($sql4);

    
}
// </form>



