<!doctype html>
<html lang="fr" xmlns="http://www.w3.org/1999/html">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.1/css/bulma.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <?php session_start(); ?>

</head>
<script>
    //fonction qui recupère les paramètres de l'URL
    function $_GET(param) {
        var vars = {};
        window.location.href.replace(location.hash, '').replace(
            /[?&]+([^=&]+)=?([^&]*)?/gi, // regexp
            function(m, key, value) { // callback
                vars[key] = value !== undefined ? value : '';
            }
        );
        if (param) {
            return vars[param] ? vars[param] : null;
        }
        return vars;
    }
</script>
</head>

<!--Connexion bdd + Bannière-->
<?php require 'header.php'; ?>
<br>

<!-- Le tableau permet d'affiché le formulaire "habilitation" en parallèle du bouton acceuil-->
<table>
    <tr>
        <td>
            <!-- Bouton acceuil -->




            <?php
            $page = basename($_SERVER["PHP_SELF"]);

            if ($page == "modification_habilitation.php") { ?>
                <a href='accueil.php'> <button class="button is-info" style='margin-left: 30px'>Accueil</button></a>
                <a href="recap.php"> <button class="button is-info" style="margin-left: 30px">Récapitulatif des habilitations</button></a>

            <?php } else { ?>
                <a href='../accueil.php'> <button class="button is-info" style='margin-left: 30px'>Accueil</button></a>
                <a href="../recap.php"> <button class="button is-info" style="margin-left: 30px">Récapitulatif des habilitations</button></a> <?php } ?>






        </td>
    </tr>
</table>

<br><br>

<h4 class="title is-5" style="border:solid"> <br> Veuillez compléter les informations ci-dessous: <br><br> </h4>

<section class="section">

    <div class="columns is-mobile">
        <div class="column is-size-5">
            <p class="has-background-primary">



                <?php


                $page = basename($_SERVER["PHP_SELF"]);

                if ($page == "modification_habilitation.php") { ?>
            <form method="GET" id="formIdUser" action="modification_habilitation.php">

            <?php } else { ?> <form method="GET" id="formIdUser" action="../modification_habilitation.php"> <?php } ?>


               



                            <?php
  $ev = "";
 if (isset($_GET['Identifiant'])) {  ?>

<?php        
                            while ($evenement = $result->fetch()) {
                                $ev = $evenement["Identifiant"];
                            }

                            } 
                            if ($ev != "") { ?>

                                <div class="columns">
                                <div class="column is-7">
                                    <label style="margin-left: 5%"> CUID :
                                        <!-- Champ permettant de à l'utilisateur de chercher d'écrire un CUID et de savoir si il existe -->
                                        <input type="text" name="Identifiant" onchange="document.getElementById('formIdUser').submit()" value="<?php if (!empty($_GET['Identifiant'])) {
                                                                                                                                                    echo $_GET['Identifiant'];
                                                                                                                                                } ?>" />
            
            
                                        <input type="hidden" id="result_deroulant" name="result_deroulant">
                                        <input type="hidden" id="deroulant0" name="deroulant0">
                                        <input type="hidden" id="deroulant1" name="deroulant1">
                                        <input type="hidden" id="deroulant2" name="deroulant2">


                            
                               
                           
                                




                            <!-- Si le CUID est mauvais un message apparait -->
                            <!-- A continuer -->
                            <!-- <div class="column is-2 message is-danger" id="message" style="display:none; color: red ">CUID n'existe pas! </div> -->
                            <div class="column is-auto"> </div>







                            <label style="margin-left: 5%">
                                Profil Métier :
                            </label>



                            <select class="button" id="selectmetier" name="profil_choisi" style="margin-left: 5%">
                                <option style='font-weight:bold'> Selectionner le profil </option>
                                <?php
                                $result = array();
                                $i = 0;
                                while ($evenement4 = $result4->fetch()) {



                                    //Cette condition permet de supprimé tous ce qui se trouve après 'GRM' et 'GPM' de la chaine.

                                    if (stristr($evenement4["Role Métier"], 'GRM') == TRUE) {
                                        $supp = 'GRM';
                                        $newString = substr($evenement4["Role Métier"], 0, strpos($evenement4["Role Métier"], $supp));
                                        $result[$i] = $newString;
                                        $result2[$i] = $evenement4["Role Métier"];
                                    } elseif (stristr($evenement4["Role Métier"], 'GPM') == TRUE) {
                                        $supp = 'GPM';
                                        $newString = substr($evenement4["Role Métier"], 0, strpos($evenement4["Role Métier"], $supp));
                                        $result[$i] = $newString;
                                        $result2[$i] = $evenement4["Role Métier"];
                                    } else {
                                        $result[$i] = $evenement4["Role Métier"];
                                        $result2[$i] = $evenement4["Role Métier"];
                                    }
                                ?>

                                    <!-- Permet d'afficher et de supprimé les "_" de la chaine 
La vrai valeur est concervé dans la "value" de l'option afin d'avoir un affichage des boutons -->
                                    <option value="<?php echo $result2[$i] ?>"> <?php echo str_replace("_", " ", $result[$i]); ?> </option>
                                <?php
                                    $i = $i + 1;
                                }
                                ?>
                            </select>




                            <br><br>


                            <button id="Click" type="submit" onClick="listmultipleresult()" class="button is-normal" style="margin-left: 5%">Envoyer</button>

                    </div>




                    <!-- Affichage des champs qui conserne l'utilisateur selectionner avec le CUID -->

                    <div class="column is-2">


                        <?php

                        $sql = "SELECT * FROM `personnes` where  `Identifiant`= '" . $_GET['Identifiant'] . "' ";
                        //  echo $sql;
                        $result = $bdd->query($sql);
                        $ev = "";
                        while ($evenement = $result->fetch()) {
                            $ev = $evenement["Identifiant"];
                        ?>

                            <p><label> Prénom : <br> <input style='width: 130px;' readOnly="readOnly" type="text" class="button" name="personnes[Prénom]" value="<?php echo $evenement['Prénom']; ?>" /></label><br>
                                <label> Nom : <br> <input style='width: 130px;' readOnly="readOnly" type="text" class="button" name="personnes[Nom]" value="<?php echo $evenement['Nom']; ?>" /></label><br>
                                <label> Mobile : <br> <input style='width: 143px;' readOnly="readOnly" type="text" class="button" name="personnes[Mobile]" value="<?php echo $evenement['Mobile']; ?>" /></label><br>
                            </p>
                    </div>
                    <div class="column is-2">
                        <p>
                            <label> Mail : <br><input style='width: 260px;' readOnly="readOnly" type="text" class="button" name="evenements[Mail]" value="<?php echo $evenement['Mail']; ?>" /></label> </br>
                            <label> ID Responsable :</br><input style='width: 110px;' readOnly="readOnly" type="text" class="button" name="evenements[Responsable]" value="<?php echo $evenement['Responsable']; ?>" /></label>
                            <label></br> Entité :</br><input style='width: 400px;' readOnly="readOnly" type="text" class="button" name="evenements[Affectation principale]" value="<?php echo $evenement['Affectation principale']; ?>" /></label>

                        </p>
                    </div>
                </div>

                <p>



                <?php
                        }
                ?>





                </label>
                <br>

                <!-- // ??????????????????????????????? -->
                <?php if (empty($evenement['Prénom']) && isset($_GET['Identifiant'])) { ?>
                    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
                    <script>
                        //When the page has loaded.
                        $(document).ready(function() {
                            $('#message').fadeIn('slow', function() {
                                $('#message').delay(5000).fadeOut();
                            });
                        });
                    </script>

                <?php } ?>

                <?php
                require 'filtre_list_deroulante.php';
                ?>

                <!-- //Affiche une liste déroulante à choix multiple qui possède la liste des métiers selon de CUID selectionner -->






















                <span id="result"> </span>
                <hr />


                </form>




                <?php

                if ($_SESSION["Pole"] == "RSI") { ?>
                    <form method="POST" id="formIdUser">
                        <a class="button is-danger" href="../envoie_mail.php"> Notification </a>

                        <a class="button is-danger" href="../supression_habilitation.php?Identifiant=<?php echo $_SESSION['Identifiant']; ?>&result_deroulant=Selectionner+le+profil+&deroulant0=Selectionner+le+profil&deroulant1=&deroulant2="> Demande de supression </a>
                    <?php } ?>
                    </form>
                    <?php if ($_SESSION["Pole"] == "Safe") { ?>
                        <a class="button is-danger" href="../supression_habilitation.php?Identifiant=<?php echo $_SESSION['Identifiant']; ?>&result_deroulant=Selectionner+le+profil+&deroulant0=Selectionner+le+profil&deroulant1=&deroulant2="> Supression </a>
                    <?php }
                    ?>


                    <br><br>

                    <?php if (isset($_GET['Identifiant'])) { ?>
                        <TABLE class="display" align="center" BORDER="1" style="width:90%">
                            <CAPTION>Liste des applications à habiliter </CAPTION>
                            <br>
                            <thead style="background-color: #eb7d4d">
                                <TH align="center">
                                    <font size="5">Habilitation
                                </TH>
                                <TH align="center">
                                    <font size="5"> Créé par
                                </TH>
                                <TH align="center">
                                    <font size="5"> Date
                                </TH>
                                <TH align="center">
                                    <font size="5"> Information Complémentaire RSI
                                </TH>
                                <TH align="center">
                                    <font size="5"> Pris en charge par
                                </TH>
                                <TH align="center">
                                    <font size="5"> Etat
                                </TH>

                            </thead>

                        <?php
                        $tab = 6;
                        $i = 1;
                    
                    }             ?>
        </div>

        <style>
            .hide {
                display: none;
            }
        </style>



        <TR>
            <?php

            while ($evenement3 = $result3->fetch()) {
                if ($evenement3["Application"] != "GDP") {  ?>
                    <form method="POST" action="/Boutons/<?php echo $evenement3["Application"] ?>.php?Identifiant=<?php echo $_GET['Identifiant']; ?>&result_deroulant=<?php echo $_GET['result_deroulant']; ?>&deroulant0=<?php echo $_GET['deroulant0']; ?>&deroulant1=<?php echo $_GET['deroulant1']; ?>&deroulant2=<?php echo $_GET['deroulant2']; ?>">
                    <?php } else { ?>
                        <form method="POST" action="/Boutons/historique_gdp.php?Identifiant=<?php echo $_GET['Identifiant']; ?>&result_deroulant=<?php echo $_GET['result_deroulant']; ?>&deroulant0=<?php echo $_GET['deroulant0']; ?>&deroulant1=<?php echo $_GET['deroulant1']; ?>&deroulant2=<?php echo $_GET['deroulant2']; ?>">
                        <?php } ?>
                        <input type="hidden" name="information" value="historique">
                        <input type="hidden" name="Application" name="Application" value='<?php echo $evenement3["Application"] ?>'>

                        <TD align="center"><input type='submit' class="button is-info" style="width:80%;width:80%" value=<?php echo $evenement3["Application"] ?> /> </TD>
                        </form>




                        <TD align="center"> <?php echo $evenement3["créé_par"]; ?> </TD>
                        <TD align="center"> <?php echo $evenement3["date"]; ?> </TD>
                        <TD align="center"> <a onclick="openForm(<?php echo $evenement3['id_habilitation']; ?>)"> <?php echo $evenement3["Informations_Complémentaires_RSI"]; ?> </a> </TD>
                        <TD align="center"> <?php echo $evenement3["pris_en_charge_par"]; ?> </TD>
                        <TD align="center"> <?php if ($evenement3["Etat"] == 0) {
                                                echo "Demande en cours";
                                            } elseif ($evenement3["Etat"] == 1) {
                                                echo "Demande accepté";
                                            } elseif ($evenement3["Etat"] == 2) {
                                                echo "Demande refusé";
                                            } elseif ($evenement3["Etat"] == 3) {
                                                echo "Demande de suppression en cours";
                                            }
                                            ?> </TD>



<?php  if ($_SESSION["Pole"] == "RSI") { ?>
</TR>
<?php }?>


                       
                            <div class="buttons">
                                <?php
                                $page = basename($_SERVER["PHP_SELF"]);


                                if ($_SESSION["Pole"] == "Safe") { ?>

                                <TD>
                                    <form method="POST" type="submit" action="Accepter_habilitation.php">
                                        <button class="button is-success" type="submit" onclick="return fonction_popup()" style="margin-right:20px;">Accepter</button>
                                        <input type="hidden" name="id_habilitation" value="<?php echo $evenement3["id_habilitation"] ?>">
                                    </form>

                                    <?php

                                    if ($page == "modification_habilitation.php") { ?>
                                        <form method="POST" type="submit" action="Refuser_habilitation.php"> <?php } else { ?> <form method="POST" id="formIdUser" action="../Refuser_habilitation.php"> <?php } ?>
                                            <button class="button is-danger" onclick="return fonction_popup()">Refuser</button>
                                            <input type="hidden" name="id_habilitation" value="<?php echo $evenement3["id_habilitation"] ?>">
                                            </form>
                                            </td>

                                            </TR>
                                    <?php } 
                            } ?>

                        




                        <script>
                            function fonction_popup() {

                                if (confirm("Validation de l'action")) {
                                    // Code à éxécuter si le l'utilisateur clique sur "OK"
                                    return true;
                                } else {
                                    // Code à éxécuter si l'utilisateur clique sur "Annuler" 
                                    return false;

                                }
                            }
                        </script>



       

























        </TR>




        <?php
        //     $_SESSION['gdp'] = $evenement3["gdp"];
        //     echo $_SESSION['gdp'];
        //     $result4 = $bdd->query("SELECT `id_gdp`, `base_gdp`, `clef_gdp` FROM `gdp` WHERE `id_gdp`= '" .  $_SESSION['gdp'] . "' ");




        ?>

        </TABLE>




        </p>
    </div>
    </div>
    </div>
    </div>
    <br>





</section>






<div class="columns">
    <div class="column">
        <p> <?php include 'Boutons' . DIRECTORY_SEPARATOR . 'gestion_bouton.php'; ?></p>
    </div>
</div>


<!-- //Permet d'afficher l'URL -->
<script>
    var chemin = window.location.pathname;
    // document.write(chemin);

    if (chemin == "/modification_habilitation.php") {

        document.write("<section class='hero is-dark'>");
        document.write("<div class='hero-body'>");
        document.write("<div class='container'></div>");
        document.write("</div> </section>");

    }
</script>





</form>

<br><br><br><br>


<!-- Popup -->
<style>
    /* Button used to open the contact form - fixed at the bottom of the page */
    .open-button {
        background-color: #555;
        color: white;
        padding: 16px 20px;
        border: none;
        cursor: pointer;
        opacity: 0.8;
        position: fixed;
        bottom: 23px;
        right: 28px;
        width: 280px;
    }

    /* The popup form - hidden by default */
    .form-popup {
        display: none;
        position: fixed;
        bottom: 290px;
        left: 15%;
        border: 3px solid #f1f1f1;
        z-index: 9;
    }

    /* Add styles to the form container */
    .form-container {
        max-width: 300px;
        padding: 10px;
        background-color: white;
    }

    /* Full-width input fields */
    .form-container input[type=text],
    .form-container input[type=password] {
        width: 100%;
        padding: 15px;
        margin: 5px 0 22px 0;
        border: none;
        background: #f1f1f1;
    }

    /* When the inputs get focus, do something */
    .form-container input[type=text]:focus,
    .form-container input[type=password]:focus {
        background-color: #ddd;
        outline: none;
    }

    /* Set a style for the submit/login button */
    .form-container .btn {
        background-color: #4CAF50;
        color: white;
        padding: 16px 20px;
        border: none;
        cursor: pointer;
        width: 100%;
        margin-bottom: 10px;
        opacity: 0.8;
    }

    /* Add a red background color to the cancel button */
    .form-container .cancel {
        background-color: red;
    }

    /* Add some hover effects to buttons */
    .form-container .btn:hover,
    .open-button:hover {
        opacity: 1;
    }
</style>




<!-- //Fonction permettant de faire une pop_UP pour update les données "Information complémentaire"-->
<div class="form-popup" id="myForm">
    <form action="/update_redirect.php" class="form-container" method="GET">
        <label><b> Information Complémentaire RSI</b></label>
        <input name="Informations_Complémentaires" type="text" required>
        <?php

        $_SESSION['Identifiant'] =   $_GET['Identifiant'];
        ?>
        <input type="hidden" id="id_habilitation" name="id_habilitation">
        <button id="form" type="submit" class="btn">Envoyer</button>
        <button type="button" class="btn cancel" onclick="closeForm()">Fermer</button>
    </form>
</div>

<script>
    function openForm(ID) {
        document.getElementById("myForm").style.display = "block";
        document.getElementById("id_habilitation").value = ID;
    }

    function closeForm() {
        document.getElementById("myForm").style.display = "none";
    }
</script>

 <?php }else{ ?>

                        <label style="margin-left: 5%"> CUID :
                            <!-- Champ permettant de à l'utilisateur de chercher d'écrire un CUID et de savoir si il existe -->
                            <input type="text" name="Identifiant" onchange="document.getElementById('formIdUser').submit()" value="<?php if (!empty($_GET['Identifiant'])) {
                                                                                                                                        echo $_GET['Identifiant'];
                                                                                                                                    } ?>" />


                            <input type="hidden" id="result_deroulant" name="result_deroulant">
                            <input type="hidden" id="deroulant0" name="deroulant0">
                            <input type="hidden" id="deroulant1" name="deroulant1">
                            <input type="hidden" id="deroulant2" name="deroulant2">



    <br><br><br><br><br><br><br>    
    <section class='hero is-dark'>
                                    <div class='hero-body'>
                                        <div class='container'></div>
                                    </div>
                                </section>
                                <?php


 } ?>