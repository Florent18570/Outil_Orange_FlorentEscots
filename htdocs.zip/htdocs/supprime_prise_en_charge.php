<?php
session_start();


try {
    $bdd = new PDO('mysql:host=localhost;dbname=Orange;charset=utf8', 'root', '');
} catch (Exception $e) {
    die('Erreur : ' . $e->getMessage());
}

date_default_timezone_set('UTC');
$today = date("j/n/Y");          // 10, 3, 2001




//permet de faire un update de l'info supplémentaire selon id de l'app
$sql_supprime_prise_en_charge = "UPDATE `etat_habilitation` SET `pris_en_charge_par`='' WHERE `id_habilitation`= '" . $_POST['id_habilitation'] . "'" ;
echo $sql_supprime_prise_en_charge;
$sql_supprime_prise_en_charge = $bdd->query($sql_supprime_prise_en_charge);

header('Location: ' . $_SERVER['HTTP_REFERER']);

?> 
</form>