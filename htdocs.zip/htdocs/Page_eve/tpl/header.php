<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="formulaire.css" />
  <title> <?php echo $page['title']; ?> </title>
  <script type="text/javascript" src="scroll_down.js"></script>

</head>