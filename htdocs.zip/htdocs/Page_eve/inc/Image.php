
<?php

$image="Page_eve/Image/"

    if(file_exists(string $image)  ))
    {

    }
    else
    {
        mkdir (string $image [, int $mode = 0777 ]);
    }


    //  affichage du dossier foreach{}

    //file_get_contents — Lit tout un fichier dans une chaîne

?>

