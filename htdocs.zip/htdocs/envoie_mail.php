<?php


//Include required PHPMailer files
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

//Define name spaces
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
session_start();

//Create an instance; passing `true` enables exceptions
$mail = new PHPMailer(true);

try {
    //Server settings
    $mail->SMTPDebug = 2;                   //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'florent.escots@gmail.com';                     //SMTP username
    $mail->Password   = 'mglmcnfiprsnwuja';                               //SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
    $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients    
    $mail->setFrom('florent.escots@gmail.com', 'Mailer');
    $mail->addAddress('florent.escots@gmail.com', 'Joe User');     //Add a recipient
                //Name is optional
//     $mail->addReplyTo('info@example.com', 'Information');
//     $mail->addCC('cc@example.com');
//     $mail->addBCC('bcc@example.com');

 
    //Content
    $mail->isHTML(true);                                  //Set email format to HTML


    try {
        $bdd = new PDO('mysql:host=localhost;dbname=Orange;charset=utf8', 'root', '');
    } catch (Exception $e) {
        die('Erreur : ' . $e->getMessage());
    }


    $sql3 = "SELECT `Application`, `id_habilitation`, `Informations_Complémentaires_RSI`,`Date`, `Etat`,`créé_par`   FROM `etat_habilitation` WHERE  `CUID`= '" . $_SESSION['Identifiant'] . "' ";
    //  echo $sql3;
     $result3 = $bdd->query($sql3);
   
// Set email format to HTML
    $mail->Subject = 'Notification habilitation ';
    $lienCUID = '<a href="http://localhost/modification_habilitation.php?Identifiant='. $_SESSION['Identifiant'] .'&result_deroulant=&deroulant0=&deroulant1=&deroulant2=">'. $_SESSION['Identifiant'] .'</a>';
    
    
   $tableau =  "<TABLE class='display' align='center' BORDER='1' style='width:90%''>
    <CAPTION>Liste des applications à habiliter </CAPTION>
    <thead style='background-color: #eb7d4d'>
        <TH align='center'>
            <font size='5'>Habilitation
        </TH>
        <TH align='center'>
            <font size='5'> Créé par
        </TH>
        <TH align='center'>
            <font size='5'> Date
        </TH>
        <TH align='center'>
            <font size='5'> Information Complémentaire RSI
        </TH>
        <TH align='center'>
            <font size='5'> Pris en charge par
        </TH>
        <TH align='center'>
            <font size='5'> Etat
        </TH>

    </thead>";
    try {
        $bdd = new PDO('mysql:host=localhost;dbname=Orange;charset=utf8', 'root', '');
    } catch (Exception $e) {
        die('Erreur : ' . $e->getMessage());
    }

    $sql3 = "SELECT *  FROM `etat_habilitation` WHERE  `CUID`= '" . $_SESSION['Identifiant']  . "' AND   (`Etat`='0' OR  `Etat`='3')  ";
     //echo $sql3;
    $result3 = $bdd->query($sql3);

    $body =  '<h1> Voici une nouvelle notification d\'habilitation :</h1>'.$lienCUID .$tableau ;

    while ($evenement3 = $result3->fetch()) { ?>

    <tr>
    <?php 
                $champtr = "<tr>"; 
              $champ6 = "<TD align='center'>".$evenement3['Application']."</TD>"; 
              $champ1 = "<TD align='center'>".$evenement3['créé_par']."</TD>"; 
              $champ2 = "<TD align='center'>".$evenement3['date']."</TD>"; 
              $champ3 = "<TD align='center'>".$evenement3['Informations_Complémentaires_RSI']."</TD>"; 
              $champ4 = "<TD align='center'>".$evenement3['pris_en_charge_par']."</TD>";  ?>
              

              <TD align='center'> <?php if ($evenement3["Etat"] == 0) {
                $champ5 = "Demande en cours";
            } elseif ($evenement3["Etat"] == 1) {
                $champ5 = "Demande accepté";
            } elseif ($evenement3["Etat"] == 2) {
                $champ5 = "Demande refusé";
            } elseif ($evenement3["Etat"] == 3) {
                $champ5 = "Demande de suppression en cours";
          
            }
            ?> </TD>


              

$champfintr = "</tr>"; ?>
            </form>


                        


<?php $body = $body . $champtr . $champ6. $champ1. $champ2. $champ3. $champ4. $champ5 .$champfintr?>
<?php } 


$mail->Body =$body ;
    
 
    
    $mail->send();
    echo 'Message has been sent';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}

?>




                        
    