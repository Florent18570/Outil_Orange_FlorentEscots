<section class="hero is-dark">
    <div class="hero-body">
        <div class="container">
        </div>
    </div>
</section>


<div class="jumbotron text-center" >
    <p>© 2021 Copyright formulaire</p>
</div>

</body>
</html>