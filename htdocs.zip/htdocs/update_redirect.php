<?php
session_start();


try {
    $bdd = new PDO('mysql:host=localhost;dbname=Orange;charset=utf8', 'root', '');
} catch (Exception $e) {
    die('Erreur : ' . $e->getMessage());
}



//permet de faire un update de l'info supplémentaire selon id de l'app
$sql4 = "UPDATE `etat_habilitation` SET `Informations_Complémentaires_RSI`='" . $_GET['Informations_Complémentaires'] . "' WHERE `CUID`= '" . $_SESSION['Identifiant'] . "' and  id_habilitation = '" . $_GET["id_habilitation"] . "' ";
echo $sql4;
$result4 = $bdd->query($sql4);

header('Location: ' . $_SERVER['HTTP_REFERER']);


?>
</form>