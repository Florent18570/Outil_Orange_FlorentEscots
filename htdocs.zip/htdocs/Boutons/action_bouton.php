<div style="margin-left: 15%">

<form method="POST">
    <input type="hidden" id="information" name="information" value="0">

    <a href="/Boutons/gdp.php?Identifiant=<?php echo $_GET['Identifiant']; ?>&result_deroulant=<?php echo $_GET['result_deroulant']; ?>&deroulant0=<?php echo $_GET['deroulant0']; ?>&deroulant1=<?php echo $_GET['deroulant1']; ?>&deroulant2=<?php echo $_GET['deroulant2']; ?>" />
    <button id="GDP" name="GDP" type='submit' class="button"> GDP </button>
    </a>
    <a href="/Boutons/activ.php?Identifiant=<?php echo $_GET['Identifiant']; ?>&result_deroulant=<?php echo $_GET['result_deroulant']; ?>&deroulant0=<?php echo $_GET['deroulant0']; ?>&deroulant1=<?php echo $_GET['deroulant1']; ?>&deroulant2=<?php echo $_GET['deroulant2']; ?>" />
    <button id="ACTIV" name="ACTIV" type="submit" class="button"> ACTIV </button>
    </a>
    <a href="/Boutons/maple.php?Identifiant=<?php echo $_GET['Identifiant']; ?>&result_deroulant=<?php echo $_GET['result_deroulant']; ?>&deroulant0=<?php echo $_GET['deroulant0']; ?>&deroulant1=<?php echo $_GET['deroulant1']; ?>&deroulant2=<?php echo $_GET['deroulant2']; ?>" />
    <button id="MAPLE" name="MAPLE" type='submit' class="button"> MAPLE </button>
    </a>
    <a href="/Boutons/livedoc.php?Identifiant=<?php echo $_GET['Identifiant']; ?>&result_deroulant=<?php echo $_GET['result_deroulant']; ?>&deroulant0=<?php echo $_GET['deroulant0']; ?>&deroulant1=<?php echo $_GET['deroulant1']; ?>&deroulant2=<?php echo $_GET['deroulant2']; ?>" />
    <button id="LIVEDOC" name="LIVEDOC" type='submit' class="button"> LIVEDOC </button>
    </a>
    <a href="/Boutons/gedaffaire.php?Identifiant=<?php echo $_GET['Identifiant']; ?>&result_deroulant=<?php echo $_GET['result_deroulant']; ?>&deroulant0=<?php echo $_GET['deroulant0']; ?>&deroulant1=<?php echo $_GET['deroulant1']; ?>&deroulant2=<?php echo $_GET['deroulant2']; ?>" />
    <button id="GEDAFFAIRES" name="GEDAFFAIRES" type='submit' class="button"> GEDAFFAIRES </button>
    </a>
    <a href="/Boutons/oine.php?Identifiant=<?php echo $_GET['Identifiant']; ?>&result_deroulant=<?php echo $_GET['result_deroulant']; ?>&deroulant0=<?php echo $_GET['deroulant0']; ?>&deroulant1=<?php echo $_GET['deroulant1']; ?>&deroulant2=<?php echo $_GET['deroulant2']; ?>" />
    <button id="OINE" name="OINE" type='submit' class="button"> OINE </button>
    </a>
    <a href="/Boutons/protys.php?Identifiant=<?php echo $_GET['Identifiant']; ?>&result_deroulant=<?php echo $_GET['result_deroulant']; ?>&deroulant0=<?php echo $_GET['deroulant0']; ?>&deroulant1=<?php echo $_GET['deroulant1']; ?>&deroulant2=<?php echo $_GET['deroulant2']; ?>" />
    <button id="Protys" name="Protys" type='submit' class="button"> Protys </button>
    </a>
    <a href="/Boutons/gescaff.php?Identifiant=<?php echo $_GET['Identifiant']; ?>&result_deroulant=<?php echo $_GET['result_deroulant']; ?>&deroulant0=<?php echo $_GET['deroulant0']; ?>&deroulant1=<?php echo $_GET['deroulant1']; ?>&deroulant2=<?php echo $_GET['deroulant2']; ?>" />
    <button id="GESCAF" name="GESCAF" type='submit' class="button"> GESCAFF </button>
    </a>
    <a href="/Boutons/e-tech.php?Identifiant=<?php echo $_GET['Identifiant']; ?>&result_deroulant=<?php echo $_GET['result_deroulant']; ?>&deroulant0=<?php echo $_GET['deroulant0']; ?>&deroulant1=<?php echo $_GET['deroulant1']; ?>&deroulant2=<?php echo $_GET['deroulant2']; ?>" />
    <button id="E-TECH" name="E-TECH" type='submit' class="button"> E-TECH </button>
    </a>
    <a href="/Boutons/mobi_v2.php?Identifiant=<?php echo $_GET['Identifiant']; ?>&result_deroulant=<?php echo $_GET['result_deroulant']; ?>&deroulant0=<?php echo $_GET['deroulant0']; ?>&deroulant1=<?php echo $_GET['deroulant1']; ?>&deroulant2=<?php echo $_GET['deroulant2']; ?>" />
    <button id="MOBI" name="MOBI" type='submit' class="button"> MOBI_V2 </button>

    <a href="/Boutons/spi.php?Identifiant=<?php echo $_GET['Identifiant']; ?>&result_deroulant=<?php echo $_GET['result_deroulant']; ?>&deroulant0=<?php echo $_GET['deroulant0']; ?>&deroulant1=<?php echo $_GET['deroulant1']; ?>&deroulant2=<?php echo $_GET['deroulant2']; ?>" />
    <button id="SPI" name="SPI" type="submit" class="button"> SPI </button>
    </a>
    <a href="/Boutons/agilis.php?Identifiant=<?php echo $_GET['Identifiant']; ?>&result_deroulant=<?php echo $_GET['result_deroulant']; ?>&deroulant0=<?php echo $_GET['deroulant0']; ?>&deroulant1=<?php echo $_GET['deroulant1']; ?>&deroulant2=<?php echo $_GET['deroulant2']; ?>" />
    <button id="AGILIS" name="AGILIS" type="submit" class="button"> AGILIS </button>
    </a>
    <a href="/Boutons/autodoc.php?Identifiant=<?php echo $_GET['Identifiant']; ?>&result_deroulant=<?php echo $_GET['result_deroulant']; ?>&deroulant0=<?php echo $_GET['deroulant0']; ?>&deroulant1=<?php echo $_GET['deroulant1']; ?>&deroulant2=<?php echo $_GET['deroulant2']; ?>" />
    <button id="AUTODOC" name="AUTODOC" type="submit" class="button"> AUTODOC </button>
    </a>
    <a href="/Boutons/pharaon.php?Identifiant=<?php echo $_GET['Identifiant']; ?>&result_deroulant=<?php echo $_GET['result_deroulant']; ?>&deroulant0=<?php echo $_GET['deroulant0']; ?>&deroulant1=<?php echo $_GET['deroulant1']; ?>&deroulant2=<?php echo $_GET['deroulant2']; ?>" />
    <button id="PHARAON" name="PHARAON" type='submit' class="button"> PHARAON </button>
    </a>
    <a href="/Boutons/pidi.php?Identifiant=<?php echo $_GET['Identifiant']; ?>&result_deroulant=<?php echo $_GET['result_deroulant']; ?>&deroulant0=<?php echo $_GET['deroulant0']; ?>&deroulant1=<?php echo $_GET['deroulant1']; ?>&deroulant2=<?php echo $_GET['deroulant2']; ?>" />
    <button id="PIDI" name="PIDI" type='submit' class="button"> PIDI </button>
    </a>
    <a href="/Boutons/gpc.php?Identifiant=<?php echo $_GET['Identifiant']; ?>&result_deroulant=<?php echo $_GET['result_deroulant']; ?>&deroulant0=<?php echo $_GET['deroulant0']; ?>&deroulant1=<?php echo $_GET['deroulant1']; ?>&deroulant2=<?php echo $_GET['deroulant2']; ?>" />
    <button id="GPC" name="GPC" type='submit' class="button"> GPC </button>
    </a>

</div>
</form>


<?php } else { ?>


<form method="POST" action="/Boutons/activ.php?Identifiant=<?php echo $_GET['Identifiant']; ?>&result_deroulant=<?php echo $_GET['result_deroulant']; ?>&deroulant0=<?php echo $_GET['deroulant0']; ?>&deroulant1=<?php echo $_GET['deroulant1']; ?>&deroulant2=<?php echo $_GET['deroulant2'] ?>;">
<input type="hidden" id="information" name="information" value="0">

<div style="margin-left: 15%">

    <a href="gdp.php?Identifiant=<?php echo $_GET['Identifiant']; ?>&result_deroulant=<?php echo $_GET['result_deroulant']; ?>&deroulant0=<?php echo $_GET['deroulant0']; ?>&deroulant1=<?php echo $_GET['deroulant1']; ?>&deroulant2=<?php echo $_GET['deroulant2']; ?>" />
    <button id="GDP" name="GDP" type='submit' class="button"> GDP </button>
    </a>
    <a href="activ.php?Identifiant=<?php echo $_GET['Identifiant']; ?>&result_deroulant=<?php echo $_GET['result_deroulant']; ?>&deroulant0=<?php echo $_GET['deroulant0']; ?>&deroulant1=<?php echo $_GET['deroulant1']; ?>&deroulant2=<?php echo $_GET['deroulant2']; ?>" />
    <button id="ACTIV" name="ACTIV" type='submit' class="button"> ACTIV </button>
    </a>
    <a href="maple.php?Identifiant=<?php echo $_GET['Identifiant']; ?>&result_deroulant=<?php echo $_GET['result_deroulant']; ?>&deroulant0=<?php echo $_GET['deroulant0']; ?>&deroulant1=<?php echo $_GET['deroulant1']; ?>&deroulant2=<?php echo $_GET['deroulant2']; ?>" />
    <button id="MAPLE" name="MAPLE" type='submit' class="button"> MAPLE </button>
    </a>
    <a href="livedoc.php?Identifiant=<?php echo $_GET['Identifiant']; ?>&result_deroulant=<?php echo $_GET['result_deroulant']; ?>&deroulant0=<?php echo $_GET['deroulant0']; ?>&deroulant1=<?php echo $_GET['deroulant1']; ?>&deroulant2=<?php echo $_GET['deroulant2']; ?>" />
    <button id="LIVEDOC" name="LIVEDOC" type='submit' class="button"> LIVEDOC </button>
    </a>
    <a href="gedaffaire.php?Identifiant=<?php echo $_GET['Identifiant']; ?>&result_deroulant=<?php echo $_GET['result_deroulant']; ?>&deroulant0=<?php echo $_GET['deroulant0']; ?>&deroulant1=<?php echo $_GET['deroulant1']; ?>&deroulant2=<?php echo $_GET['deroulant2']; ?>" />
    <button id="GEDAFFAIRES" name="GEDAFFAIRES" type='submit' class="button"> GEDAFFAIRES </button>
    </a>
    <a href="oine.php?Identifiant=<?php echo $_GET['Identifiant']; ?>&result_deroulant=<?php echo $_GET['result_deroulant']; ?>&deroulant0=<?php echo $_GET['deroulant0']; ?>&deroulant1=<?php echo $_GET['deroulant1']; ?>&deroulant2=<?php echo $_GET['deroulant2']; ?>" />
    <button id="OINE" name="OINE" type='submit' class="button"> OINE </button>
    </a>
    <a href="protys.php?Identifiant=<?php echo $_GET['Identifiant']; ?>&result_deroulant=<?php echo $_GET['result_deroulant']; ?>&deroulant0=<?php echo $_GET['deroulant0']; ?>&deroulant1=<?php echo $_GET['deroulant1']; ?>&deroulant2=<?php echo $_GET['deroulant2']; ?>" />
    <button id="Protys" name="Protys" type='submit' class="button"> Protys </button>
    </a>
    <a href="gescaff.php?Identifiant=<?php echo $_GET['Identifiant']; ?>&result_deroulant=<?php echo $_GET['result_deroulant']; ?>&deroulant0=<?php echo $_GET['deroulant0']; ?>&deroulant1=<?php echo $_GET['deroulant1']; ?>&deroulant2=<?php echo $_GET['deroulant2']; ?>" />
    <button id="GESCAF" name="GESCAF" type='submit' class="button"> GESCAFF </button>
    </a>
    <a href="e-tech.php?Identifiant=<?php echo $_GET['Identifiant']; ?>&result_deroulant=<?php echo $_GET['result_deroulant']; ?>&deroulant0=<?php echo $_GET['deroulant0']; ?>&deroulant1=<?php echo $_GET['deroulant1']; ?>&deroulant2=<?php echo $_GET['deroulant2']; ?>" />
    <button id="E-TECH" name="E-TECH" type='submit' class="button"> E-TECH </button>
    </a>
    <a href="mobi_v2.php?Identifiant=<?php echo $_GET['Identifiant']; ?>&result_deroulant=<?php echo $_GET['result_deroulant']; ?>&deroulant0=<?php echo $_GET['deroulant0']; ?>&deroulant1=<?php echo $_GET['deroulant1']; ?>&deroulant2=<?php echo $_GET['deroulant2']; ?>" />
    <button id="MOBI" name="MOBI" type='submit' class="button"> MOBI_V2 </button>

    <a href="spi.php?Identifiant=<?php echo $_GET['Identifiant']; ?>&result_deroulant=<?php echo $_GET['result_deroulant']; ?>&deroulant0=<?php echo $_GET['deroulant0']; ?>&deroulant1=<?php echo $_GET['deroulant1']; ?>&deroulant2=<?php echo $_GET['deroulant2']; ?>" />
    <button id="SPI" name="SPI" type="submit" class="button"> SPI </button>
    </a>
    <a href="agilis_portaffaire.php?Identifiant=<?php echo $_GET['Identifiant']; ?>&result_deroulant=<?php echo $_GET['result_deroulant']; ?>&deroulant0=<?php echo $_GET['deroulant0']; ?>&deroulant1=<?php echo $_GET['deroulant1']; ?>&deroulant2=<?php echo $_GET['deroulant2']; ?>" />
    <button id="AGILIS" name="AGILIS/PORTAFFAIRE" type='submit' class="button"> AGILIS </button>
    </a>
    <a href="autodoc.php?Identifiant=<?php echo $_GET['Identifiant']; ?>&result_deroulant=<?php echo $_GET['result_deroulant']; ?>&deroulant0=<?php echo $_GET['deroulant0']; ?>&deroulant1=<?php echo $_GET['deroulant1']; ?>&deroulant2=<?php echo $_GET['deroulant2']; ?>" />
    <button id="AUTODOC" name="AUTODOC" type="submit" class="button"> AUTODOC </button>
    </a>
    <a href="pharaon.php?Identifiant=<?php echo $_GET['Identifiant']; ?>&result_deroulant=<?php echo $_GET['result_deroulant']; ?>&deroulant0=<?php echo $_GET['deroulant0']; ?>&deroulant1=<?php echo $_GET['deroulant1']; ?>&deroulant2=<?php echo $_GET['deroulant2']; ?>" />
    <button id="PHARAON" name="PHARAON" type='submit' class="button"> PHARAON </button>
    </a>
    <a href="pidi.php?Identifiant=<?php echo $_GET['Identifiant']; ?>&result_deroulant=<?php echo $_GET['result_deroulant']; ?>&deroulant0=<?php echo $_GET['deroulant0']; ?>&deroulant1=<?php echo $_GET['deroulant1']; ?>&deroulant2=<?php echo $_GET['deroulant2']; ?>" />
    <button id="PIDI" name="PIDI" type='submit' class="button"> PIDI </button>
    </a>
    <a href="gpc.php?Identifiant=<?php echo $_GET['Identifiant']; ?>&result_deroulant=<?php echo $_GET['result_deroulant']; ?>&deroulant0=<?php echo $_GET['deroulant0']; ?>&deroulant1=<?php echo $_GET['deroulant1']; ?>&deroulant2=<?php echo $_GET['deroulant2']; ?>" />
    <button id="GPC" name="GPC" type='submit' class="button"> GPC </button>
    </a>


<?php    } ?>

</div>
</form>