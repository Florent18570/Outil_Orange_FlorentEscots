<?php
require 'inc' . DIRECTORY_SEPARATOR . 'config.php';
$page['title'] = 'Détail Evenement';

?>

<body>
    <?php
    if (isset($_GET['Identifiant'])) {
    


            //Connexion à la base de données

            try {
                $bdd = new PDO('mysql:host=localhost;dbname=Orange;charset=utf8', 'root', '');
            } catch (Exception $e) {
                die('Erreur : ' . $e->getMessage());
            }

            //Requete SQL pour retourner les informations d'un utilisateur
            $sql = "SELECT * FROM `personnes` where  `Identifiant`= '" . $_GET['Identifiant'] . "' ";
            // echo $sql;
            $result = $bdd->query($sql);
            $evenement = $result->fetch();



            // r
            $sql3 = "SELECT *  FROM `etat_habilitation` WHERE  `CUID`= '" . $_GET['Identifiant']  . "' AND   (`Etat`='0'  OR  `Etat`='1' OR  `Etat`='2' OR  `Etat`='3')  ";
            // echo $sql3;
            $result3 = $bdd->query($sql3);

            //Requete SQL pour retourner les informations d'un utilisateur
            $sql = "SELECT * FROM `personnes` where  `Identifiant`= '" . $_GET['Identifiant'] . "' ";
            // echo $sql;
            $result = $bdd->query($sql);



            // requete pour comparer si Affectation principale de l'utilisateur correspond à un des entités
            $sql4 = "SELECT `Role Métier`, `Entite` FROM `metier_entité` WHERE  `Entite`= '" . $evenement['Affectation principale'] . "' ";
            echo $sql4;
            $result4 = $bdd->query($sql4);
        
    }


    ?>


    <!-- La selection permet d'afficher le header de mes pages #a3431a-->
    <section class="hero is-primary" style="background-color : #343a40">
        <div class="columns">
            <div class="column is-narrow" style="padding-left: 100px">
                <br>
                <img src="../Ressource/orange.png" width="85" height="85">
            </div>
            <div class="column">
                <br><br>
                <h1 class="title">
                    Modification d'une habilitation
                </h1>
            </div>
        </div>
        <br>
    </section>