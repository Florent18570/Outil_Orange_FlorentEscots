<?php
session_start();


try {
    $bdd = new PDO('mysql:host=localhost;dbname=Orange;charset=utf8', 'root', '');
} catch (Exception $e) {
    die('Erreur : ' . $e->getMessage());
}

date_default_timezone_set('UTC');
$today = date("j/n/Y");          // 10, 3, 2001


echo $_POST['id_habilitation'];

//permet de faire un update de l'info supplémentaire selon id de l'app
$sqlajout_prise_en_charge = "UPDATE `etat_habilitation` SET `pris_en_charge_par`='" . $_POST['prise_en_charge'] . "' WHERE `id_habilitation`= '" . $_POST['id_habilitation'] . "'" ;
echo $sqlajout_prise_en_charge;
$result_prise_en_charge = $bdd->query($sqlajout_prise_en_charge);

header('Location: ' . $_SERVER['HTTP_REFERER']);

?> 
</form>