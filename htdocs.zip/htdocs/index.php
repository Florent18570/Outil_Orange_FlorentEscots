<!DOCTYPE html>
<html>

<head>
	<title>Ajax POST request with JQuery and PHP</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
	<style type="text/css">
		body {
			font-family: calibri;
		}

		.box {
			margin-bottom: 10px;
		}

		.box label {
			display: inline-block;
			width: 80px;
			text-align: right;
			margin-right: 10px;
		}

		.box input,
		.box textarea {
			border-radius: 3px;
			border: 1px solid #ddd;
			padding: 5px 10px;
		}

		.btn-submit {
			margin-left: 90px;
		}
	</style>
</head>

<body>
	<h2>Ajax POST request with JQuery and PHP - <a href="https://www.cluemediator.com" target="_blank">Clue Mediator</a></h2>

	<form action="/submission.php" method="POST">
		<div class="box">
			<label>First Name:</label><input hidden type="text" name="firstName" id="firstName" value="tootototoototot" />
		</div>
		<div class="box">
			<label>Last Name:</label><input type="text" name="lastName" id="lastName" />
		</div>
		<div class="box">
			<label>Email:</label><input type="email" name="email" id="email" />
		</div>
		<div class="box">
			<label>Message:</label><textarea type="text" name="message" id="message"></textarea>
		</div>
		<input id="submit" type="submit" class="btn-submit" value="Submit" />
	</form>


	<script>
		$(document).ready(function() {

			$("#submit").click(function() {

				document.write(ID);
				var data = {
					'test': 'abc'
				};

				$.ajax({
					type: "POST",
					url: "submission.php",
					data: 'name' + ID,
					cache: false,

				});

			});

		});
	</script>
</body>

</html>