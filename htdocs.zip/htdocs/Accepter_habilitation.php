<?php
session_start();


try {
    $bdd = new PDO('mysql:host=localhost;dbname=Orange;charset=utf8', 'root', '');
} catch (Exception $e) {
    die('Erreur : ' . $e->getMessage());
}



//permet d'accepter les habilitation qui sont en Etat "Demande en cours"
echo $_POST['id_habilitation'];

$sql = "UPDATE `etat_habilitation` SET `Etat`='1' WHERE  `Etat`='0' AND `id_habilitation`=    '" . $_POST['id_habilitation'] . "' AND `CUID`= '" . $_SESSION['Identifiant'] . "'  ";
echo $sql;
$result = $bdd->query($sql);

header('Location: ' . $_SERVER['HTTP_REFERER']);


?>
</form>