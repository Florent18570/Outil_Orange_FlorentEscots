<?php
session_start();


$_SESSION["Pole"] = $_POST["Pole"];



header('Location: modification_habilitation.php ' );


?>
</form>